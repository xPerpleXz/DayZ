name = "TransitBus Mod";
picture = "";
logo = "";
logoOver = "";
tooltip = "TransitBus Mod";
overview = "Stellt den originalen DayZ TransitBus als nutzbares Fahrzeug ins Spiel. Nutzt ausschließlich Vanilla-Ressourcen.";
author = "xPerpleXz";
version = "1.2";
