class CfgPatches {
    class TransitBusMod {
        units[] = {"TransitBus"}; 
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Vehicles_Wheeled"};
    };
};

class CfgVehicles {
    class CarScript;
    
    // Die EventGroup wird hier definiert
    class TransitBus : CarScript {
        scope = 2;
        displayName = "Transit Bus";
        model = "\TransitBus\TransitBus.p3d";
        vehicleClass = "Car";

        // Hier definieren wir die attachments
        attachments[] = {
            "CarBattery",
            "SparkPlug",
            "CarRadiator",
            "HeadlightH7",
            "TransitBusWheel_1_1",
            "TransitBusWheel_1_2",
            "TransitBusWheel_2_1",
            "TransitBusWheel_2_2"
        };

        class DamageSystem {
            class GlobalHealth {
                class Health {
                    hitpoints = 5000;
                    healthLevels[] = {
                        {1.0, {"TransitBus\data\ikarus_body.rvmat"}},
                        {0.7, {"TransitBus\data\ikarus_body.rvmat"}},
                        {0.5, {"TransitBus\data\ikarus_body_damage.rvmat"}},
                        {0.3, {"TransitBus\data\ikarus_body_damage.rvmat"}},
                        {0.0, {"TransitBus\data\ikarus_body_destruct.rvmat"}}
                    };
                };
            };

            class DamageZones {
                class Window {
                    class Health {
                        hitpoints = 100;
                        healthLevels[] = {
                            {1.0, {"TransitBus\data\glass.rvmat"}},
                            {0.7, {"TransitBus\data\glass.rvmat"}},
                            {0.5, {"TransitBus\data\glass_i_damage.rvmat"}},
                            {0.3, {"TransitBus\data\glass_i_damage.rvmat"}},
                            {0.0, {"TransitBus\data\glass_i_destruct.rvmat"}}
                        };
                    };
                };
            };
        };

        class Cargo {
            itemsCargoSize[] = {10, 40}; // Passagierraum
        };

        class AnimationSources {
            class Doors {
                source = "user";
                animPeriod = 1;
                initPhase = 0;
            };
        };

        class Wheels {
            class TransitBusWheel_1_1 {
                boneName = "wheel_1_1";
                steering = 1;
            };
            class TransitBusWheel_1_2 {
                boneName = "wheel_1_2";
                steering = 1;
            };
            class TransitBusWheel_2_1 {
                boneName = "wheel_2_1";
                steering = 0;
            };
            class TransitBusWheel_2_2 {
                boneName = "wheel_2_2";
                steering = 0;
            };
        };
    };
};

// EventGroup hier definieren
class CfgEventGroups {
    class VehicleSpawns {
        name = "VehicleSpawns"; // Der Name der EventGroup
        type = "Vehicle"; // Typ der EventGroup
    };
};

class CfgEventSpawns {
    class VehicleTransitBus {
        eventGroup = "VehicleSpawns"; // EventGroup zuweisen
        positions[] = {
            {11909.426, 6432.040, 49.747}, // Position 1
            {10400.112, 2237.542, 5.930}   // Position 2
        };
    };
};
