protocol = 1;
publishedid = 3466971268;
name = "TransitBus";
timestamp = 5250493015427276500;
